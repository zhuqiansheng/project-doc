package ustc.xupernft.system.service;

import ustc.xupernft.frame.service.IBaseService;
import ustc.xupernft.rpc.annotation.RpcServiceAnnotation;

@RpcServiceAnnotation
public interface IBaseSpringrainService extends IBaseService {

}