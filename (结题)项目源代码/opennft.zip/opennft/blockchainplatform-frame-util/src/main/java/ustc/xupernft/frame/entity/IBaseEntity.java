package ustc.xupernft.frame.entity;

/**
 * Entity的基础接口
 *
 * @author springrain<9 iuorg @ gmail.com>
 * @version 2013-03-19 11:08:15
 * @copyright {@link jiagou.com}
 * @see IBaseEntity
 */
public interface IBaseEntity extends java.io.Serializable {

}
