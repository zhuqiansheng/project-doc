package ustc.xupernft.service.impl;

import ustc.xupernft.frame.entity.IBaseEntity;
import ustc.xupernft.entity.NftWorksPrice;
import ustc.xupernft.service.INftWorksPriceService;
import ustc.xupernft.system.service.impl.BaseSpringrainServiceImpl;
import org.springframework.stereotype.Service;

/**
 * TODO 在此加入类描述
 * @author springrain<Auto generate>
 * @version  2021-12-21 17:58:29
 */

@Service("nftWorksPriceService")
public class NftWorksPriceServiceImpl extends BaseSpringrainServiceImpl implements INftWorksPriceService {

   
    @Override
	public String  save(IBaseEntity entity ) throws Exception{
	    NftWorksPrice nftWorksPrice=(NftWorksPrice) entity;
	    return super.save(nftWorksPrice).toString();
	}


	@Override
    public Integer update(IBaseEntity entity ) throws Exception{
		NftWorksPrice nftWorksPrice=(NftWorksPrice) entity;
		return super.update(nftWorksPrice);
    }
	
    @Override
	public NftWorksPrice findNftWorksPriceById(String id) throws Exception{
		return super.findById(id,NftWorksPrice.class);
	}

}
