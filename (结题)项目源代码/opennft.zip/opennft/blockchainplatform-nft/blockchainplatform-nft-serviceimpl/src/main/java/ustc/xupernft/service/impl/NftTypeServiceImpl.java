package ustc.xupernft.service.impl;

import ustc.xupernft.frame.entity.IBaseEntity;
import ustc.xupernft.frame.util.Finder;
import ustc.xupernft.entity.NftType;
import ustc.xupernft.service.INftTypeService;
import ustc.xupernft.vo.LabelValuePairVO2;
import ustc.xupernft.system.service.impl.BaseSpringrainServiceImpl;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * TODO 在此加入类描述
 *
 * @author springrain<Auto generate>
 * @version 2021-12-21 17:58:16
 */

@Service("nftTypeService")
public class NftTypeServiceImpl extends BaseSpringrainServiceImpl implements INftTypeService {


    @Override
    public String save(IBaseEntity entity) throws Exception {
        NftType nftType = (NftType) entity;
        return super.save(nftType).toString();
    }


    @Override
    public Integer update(IBaseEntity entity) throws Exception {
        NftType nftType = (NftType) entity;
        return super.update(nftType);
    }

    @Override
    public NftType findNftTypeById(String id) throws Exception {
        return super.findById(id, NftType.class);
    }

    @Override
    public List<LabelValuePairVO2> getLabelValuePair() throws Exception {
        Finder selectFinder = Finder.getSelectFinder(NftType.class," name as label,value ");
        return super.queryForList(selectFinder, LabelValuePairVO2.class);
    }

}
