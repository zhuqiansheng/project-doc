package ustc.xupernft.dto;

import ustc.xupernft.entity.NftUserChainplat;

import java.io.Serializable;

/**
 * @descriptions: 用户链平台信息
 * @author: YSK
 * @date: 2021/12/27 13:05
 * @version: 1.0
 */
public class UserChainplatInfoDTO extends NftUserChainplat implements Serializable {
}
