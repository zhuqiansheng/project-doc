package ustc.xupernft.service;

import ustc.xupernft.entity.NftWorksPrice;
import ustc.xupernft.rpc.annotation.RpcServiceAnnotation;
import ustc.xupernft.system.service.IBaseSpringrainService;

/**
 * TODO 在此加入类描述
 * @author springrain<Auto generate>
 * @version  2021-12-21 17:58:29
 */
@RpcServiceAnnotation
public interface INftWorksPriceService extends IBaseSpringrainService {
	
	/**
	 * 根据ID查找
	 * @param id
	 * @return
	 * @throws Exception
	 */
	NftWorksPrice findNftWorksPriceById(String id) throws Exception;
	
	
	
}
