package ustc.xupernft.service;


import ustc.xupernft.vo.MailVO;
import ustc.xupernft.rpc.annotation.RpcServiceAnnotation;
import ustc.xupernft.system.service.IBaseSpringrainService;

@RpcServiceAnnotation
public interface INftMailService extends IBaseSpringrainService {
    public MailVO sendMail(MailVO mailVo) throws Exception;

    public void checkMail(MailVO mailVo) throws Exception;


    public void sendMimeMail(MailVO mailVo) throws Exception;

    public String getMailSendFrom() throws Exception;
}
