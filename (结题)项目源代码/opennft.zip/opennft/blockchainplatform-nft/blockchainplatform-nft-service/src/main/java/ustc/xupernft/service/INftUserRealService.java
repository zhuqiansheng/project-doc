package ustc.xupernft.service;

import ustc.xupernft.entity.NftUserReal;
import ustc.xupernft.rpc.annotation.RpcServiceAnnotation;
import ustc.xupernft.system.service.IBaseSpringrainService;

/**
 * TODO 在此加入类描述
 * @author springrain<Auto generate>
 * @version  2021-12-22 09:18:06
 */
@RpcServiceAnnotation
public interface INftUserRealService extends IBaseSpringrainService {
	
	/**
	 * 根据ID查找
	 * @param id
	 * @return
	 * @throws Exception
	 */
	NftUserReal findNftUserRealById(String id) throws Exception;
	
	
	
}
