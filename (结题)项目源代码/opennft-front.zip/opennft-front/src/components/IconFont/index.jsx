import { createFromIconfontCN } from '@ant-design/icons';

const IconFont = createFromIconfontCN({
	scriptUrl: '//at.alicdn.com/t/font_2462441_yu4z3zoxh8.js',
});

export default IconFont;
