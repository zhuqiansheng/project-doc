package net.shengjian.makerone.dto;

/**
 * @descriptions: 搜索的作品结果
 * @author: YSK
 * @date: 2022/1/7 15:08
 * @version: 1.0
 */
public class SearchWorksResultDTO extends UserCollectionWorksDTO {
}
